<?php
\Core\Session::destroy();
exit();
