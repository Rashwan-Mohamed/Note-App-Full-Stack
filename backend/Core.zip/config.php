<?php
    return ['database' => ['host' => 'sql213.infinityfree.com',
        'port' => 3306,
        'dbname' => 'if0_39073653_XXX',
        "charset" => 'utf8mb4']];