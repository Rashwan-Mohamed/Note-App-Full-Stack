<?php

namespace Http\Forms;

class LoginForm
{

}